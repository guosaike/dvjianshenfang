from django.urls import path,re_path
from . import views

urlpatterns = [
    # 登录接口
    path('logintest/', views.LoginView.as_view()),
    # 修改个人信息接口
    path('guanli/', views.GuanliApiview.as_view()),
    re_path('guanli/(?P<pk>\d+)/', views.GuanlidetailApiview.as_view()),
    # 寄样人管理
    path('cs/', views.Csview.as_view()),
    re_path('cs/(?P<pk>\d+)/', views.Csdetailview.as_view()),
    # 领养人管理
    path('gm/', views.Gmview.as_view()),
    re_path('gm/(?P<pk>\d+)/', views.Gmdetailview.as_view()),
    # 分类管理
    path('fl/', views.Flview.as_view()),
    re_path('fl/(?P<pk>\d+)/', views.Fldetailview.as_view()),
    # 地区管理
    path('dq/', views.Dqview.as_view()),
    re_path('dq/(?P<pk>\d+)/', views.Dqdetailview.as_view()),

    # 宠物管理
    # 全部宠物接口
    path('jq/', views.Jqview.as_view()),
    re_path('jq/(?P<pk>\d+)/', views.Jqdetailview.as_view()),

    # 地址管理
    path('dz/', views.Dzview.as_view()),
    re_path('dz/(?P<pk>\d+)/', views.Dzdetailview.as_view()),
    # 订单管理
    path('dd/', views.Ddview.as_view()),
    re_path('dd/(?P<pk>\d+)/', views.Dddetailview.as_view()),
]