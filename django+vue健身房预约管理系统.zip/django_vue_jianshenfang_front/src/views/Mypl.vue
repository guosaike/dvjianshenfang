<template>
  <div>
    <div class="title">我的评论</div>

    <div>
      <div v-for="item in pldata" :key="item.id" style="margin-bottom:20px;border-bottom: 1px dashed #cedce4;padding: 10px 0;">
                  <div style="display: flex;align-items: center;">
                    <el-avatar :size="32" :src="Host+'/upimg/' + item.shui.img_url"
                      style="flex-shrink: 0;margin-right:10px;" />
                    <div style="flex:1;">
                      <div style="font-weight: 600;font-size: 16px;">{{ item.shui.username }}</div>
                      <div style="font-size: 14px;color: #999;">{{ item.pl_date }}</div>
                      <div style="font-size: 14px;color: #999;">{{ item.jingqu.name }}</div>

                      <br>
                      
                      <div>{{ item.content }}</div>
                    </div>
                    <!-- <div style="flex-shrink: 0;"><el-button link type="primary">推荐</el-button> 1</div> -->
                  </div>
                </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pldata: [],
    }
  },
  created() {
    this.userInfo = localStorage.getItem("userInfo");
    this.userInfoid = localStorage.getItem("userInfoid");
    this.token = localStorage.getItem("token");
    this.isAdmin = localStorage.getItem("isAdmin");
    this.mypinglun();
  },

  methods: {
    mypinglun(){
      this.$api.mypinglun(
            {
                pageNum:1,
                pageSize:8,
                userInfoid:this.userInfoid,
            }
        ).then(res=>{
            if (res.data.code === 200){
                this.pldata = res.data.data
            }
        })
    },
  }
}
</script>

<style>
.title {
  color: #152844;
  font-weight: 600;
  font-size: 18px;
  line-height: 24px;
  margin-bottom: 4px;
}

.order-item {
  margin-top: 16px;
  background: #f7f9fb;
  border-radius: 4px;
  padding: 16px;
  box-sizing: border-box;
}
</style>