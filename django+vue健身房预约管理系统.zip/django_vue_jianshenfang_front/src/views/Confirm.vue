<template>
  <div style="display: flex;padding-top: 20px;">
    <div style="width: 65%;padding-right: 10px;border-right: 1px solid #e5e5e5;">
      <div class="title">订单明细</div>
      <div style="margin: 10px 0;">
        <el-table :data="Detailinfo" style="width: 100%">
          <el-table-column label="景区图片">
            <template #default="scope">
              <img :src="Host+'/upimg/' + scope.row.img_url" width="100" height="100">
              <!-- <img :src="scope.row.img_url" width="50" height="50"> -->
            </template>
          </el-table-column>
          <el-table-column prop="price" label="价格" :width="100"></el-table-column>
          <el-table-column prop="name" label="名称" :width="100"></el-table-column>
          <el-table-column prop="" label="数量" :width="100"></el-table-column>
          <el-table-column prop="" label="操作" :width="100">
            <template #default="scope">
              <el-icon>
                <Delete />
              </el-icon>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <br>

      <el-button @click="openAddressDialog" type="primary" plain>选择收货地址</el-button>

      <br>
      <br>

      <div class="address-container">
        <div class="address-title">姓名: {{ addressSelected.username }}</div>
        <br>
        <div class="address-title">手机号: {{ addressSelected.shouji }}</div>
        <br>
        <div class="address-title">地址: {{ addressSelected.addr }}</div>
        <br>
        <div class="address-detials"></div>
        
      </div>
      <el-dialog title="选择地址" v-model="addressDialogVisible" width="800px">
        <el-table stripe empty-text="无地址信息，请先在个人中心添加地址" :data="addressData" style="width: 100%">
          <el-table-column prop="username" label="收货人姓名" width="200">
          </el-table-column>
          <el-table-column prop="shouji" label="手机号" width="140">
          </el-table-column>
          <el-table-column prop="addr" label="地址">
          </el-table-column>
          <el-table-column label="操作" width="120">
            <template #default="scope">
              <el-button size="mini" @click="selectAddress(scope.row)">选择</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-dialog>

      <!-- <div class="title">备注</div>
      <el-input type="textarea" :rows="3" placeholder="请输入内容" v-model="textarea"></el-input> -->
    </div>
    <div style="width: 35%;padding-left: 10px">
      <div class="title">结算</div>
      <div class="jg-row">
        <span>门票价格</span>
        <span class="jg-text">¥200</span>
      </div>
      <!-- <div class="jg-row">
        <span>门票优惠</span>
        <span class="jg-text">¥0</span>
      </div>
      <div class="jg-row">
        <span>门票折扣</span>
        <span class="jg-text">¥0</span>
      </div> -->
      <el-divider />
      <div class="jg-row">
        <span style="font-weight: 700;">合计</span>
        <span class="jg-text">¥200</span>
      </div>
      <div style="margin-top: 20px;text-align: right;">
        <el-button round @click="$router.back()">返回</el-button>
        <!-- <el-button round type="primary" @click="$router.push('/home/pay')">结算</el-button> -->
        <el-button round type="primary" @click="buy()">结算</el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      textarea: '',
      tableData: [{}],
      Detailinfo: [],
      addressDialogVisible: false,
      addressData: [
        { username: '张三', shouji: '123456789', addr: '北京市朝阳区东三环北路', id: 1 },
        { username: '李四', shouji: '123456789', addr: '北京市朝阳区东三环北路', id: 2 },
        { username: '王五', shouji: '123456789', addr: '北京市朝阳区东三环北路', id: 3 },
        { username: '赵六', shouji: '123456789', addr: '北京市朝阳区东三环北路', id: 4 },
        { username: '钱七', shouji: '123456789', addr: '北京市朝阳区东三环北路', id: 5 },
      ],
      addressSelected: {},
    }
  },
  created() {
    this.userInfo = localStorage.getItem("userInfo");
    this.userInfoid = localStorage.getItem("userInfoid");
    this.token = localStorage.getItem("token");
    this.isAdmin = localStorage.getItem("isAdmin");
    let id = this.$route.query.id;
    // 详情
    this.xiangqing(id);
    // 地址
    this.getAddress();
  },

  methods: {
    // 详情
    xiangqing(id){
      this.$api.xiangqing({
              id: id,
          }).then(res => {
        if (res.data.code === 200) {
          this.Detailinfo.push(res.data.data)
          }
        });
    },
    // 地址
    getAddress(){
      this.$api.getAddress({
            pageNum: 1,
            pageSize: 10,
            userinfo:this.userInfoid
          }).then(res => {
        if (res.data.code === 200) {
          // console.log(res.data.data)
          this.addressData = res.data.data
          }
        });
    },
    // 买
    buy(){
      // $router.push('/home/pay')
      if(!this.addressSelected.addr){
          this.$message.error('请选择地址！')
      }else{
          this.$confirm('模拟支付宝支付，是否确认支付', '支付订单', {
                  confirmButtonText: '支付',
                  cancelButtonText: '取消',
                  type: 'warning'
              }).then(() => {
                  function getCurrentDate(format) {
                        var now = new Date();
                        var year = now.getFullYear(); //得到年份
                        var month = now.getMonth();//得到月份
                        var date = now.getDate();//得到日期
                        var day = now.getDay();//得到周几
                        var hour = now.getHours();//得到小时
                        var minu = now.getMinutes();//得到分钟
                        var sec = now.getSeconds();//得到秒
                        month = month + 1;
                        if (month < 10) month = "0" + month;
                        if (date < 10) date = "0" + date;
                        if (hour < 10) hour = "0" + hour;
                        if (minu < 10) minu = "0" + minu;
                        if (sec < 10) sec = "0" + sec;
                        var time = "";
                        //精确到天
                        if(format==1){
                            time = year + "-" + month + "-" + date;
                        }
                        //精确到分
                        else if(format==2){
                            time = year + "-" + month + "-" + date+ " " + hour + ":" + minu + ":" + sec;
                        }
                        return time;
                        }
                  var currentDate = getCurrentDate(1);
                  console.log(this.addressData,'22222222222222222222222222222222')
                  this.$api.addOrder({
                      // 买家
                      shui_id:this.userInfoid,
                      // 卖家
                      maijia:this.Detailinfo[0].maijia.username,
                      // 时间
                      gmsj:currentDate,
                      // 买的什么
                      title:this.Detailinfo[0].name,
                      // 图片地址
                      img_url:this.Detailinfo[0].img_url,
                      // 花了多少钱
                      price:this.Detailinfo[0].price,
                      // 电话
                      phone: this.addressSelected.shouji,
                      // 地址
                      addr:this.addressSelected.addr,
                  }).then(res=>{
                      console.log(res);
                      if(res.data.code===200){
                        this.$message.success('支付成功')
                        this.$router.push('/home/usercenter')
                      }else {
                          this.$message.error(res.data.message)
                      }
                  })
                })
      }
    },
    openAddressDialog() {
      this.addressDialogVisible = true
    },
    selectAddress(row){
      this.addressSelected = row
      this.addressDialogVisible = false
    },
  }
}
</script>


<style scoped>
.title {
  color: #152844;
  font-weight: 600;
  font-size: 18px;
  height: 26px;
  line-height: 26px;
  margin: 0;
  margin-bottom: 10px;
}

.jg-text {
  font-weight: 500;
  color: #ff8a00;
  font-size: 16px;
}

.jg-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  color: #152844;
  font-size: 14px;
}
</style>