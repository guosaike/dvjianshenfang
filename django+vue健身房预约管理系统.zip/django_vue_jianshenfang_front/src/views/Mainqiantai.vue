<template>
  <div>
    <el-container>
      <el-header class="el-header">
        <div @click="$router.push('/home/index')">
          <img src="/src/assets/1.jpg" alt="Local Image" class="wh-32">
        </div>



        <div style="margin-left: 900px;margin-right: 20px;">
          
          <div v-if="!this.userInfo">
            <el-button type="primary" @click="$router.push('/login')">前台登录</el-button>
          </div>
          <div v-else>
            <el-dropdown>
            <div style="display: flex;align-items: center;justify-content: center;">
              <el-avatar :size="32"
                src="https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png" />
              <span style="margin-left:10px;color:#909399;">{{ userInfo }}</span>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="$router.push('/home/usercenter')">个人中心</el-dropdown-item>
                <el-dropdown-item @click="quitLogin()">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          </div>
        </div>

        <div style="margin-right: 20px;">
            <div style="display: flex;align-items: center;justify-content: center;">
              <el-button @click="$router.push('/login')">后台登录</el-button>
            </div>
        </div>

      </el-header>
      <el-main class="el-main">
        <RouterView />
      </el-main>
      <el-footer>
        <div class="footer-text">2022-2024 © B站程序员科科 · 微信:python_kk</div>
      </el-footer>
    </el-container>
  </div>
</template>

<script>

export default {
    name: "main",
    data() {
        return {
          // 当前登录用户名
          userInfo:''
        };
    },
    created() {
    this.userInfo = localStorage.getItem("userInfo");
    this.userInfoid = localStorage.getItem("userInfoid");
    this.isAdmin = localStorage.getItem("isAdmin");
  },
    methods: {
      quitLogin() {
      localStorage.clear()
      this.$router.push('/login')
      this.$message.success('退出成功')
    }
    }
}

</script>

<style>
.el-header {
  height: 56px;
  background-color: #FFF;
  border-bottom: 1px solid #cedce4;
  padding: 0 260px;
  display: flex;
  align-items: center;
  box-sizing: border-box;
  justify-content: space-between;
}

.el-main {
  width: 1130px;
  padding: 10px 0;
  box-sizing: border-box;
  margin: 0 auto;
}

.wh-32 {
  width: 35px;
  height: 35px;
  cursor: pointer;
}

.footer-text {
  text-align: center;
  line-height: 16px;
  font-size: 12px;
  color: #aeaeae;
  padding: 10px 0;
}
</style>